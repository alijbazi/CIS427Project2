
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.SocketHandler;


//Runnable class allows us to create a task
//to be run on a thread
public class ClientHandler implements Runnable {
    private Socket socket;  //connected socket
    private ServerSocket serverSocket;  //server's socket
    private int clientNumber;
    private ArrayList<ClientHandler> clients;
    private BufferedWriter writeToClient;
    //create an instance
    public ClientHandler(int clientNumber, Socket socket, ServerSocket serverSocket, ArrayList<ClientHandler> clients) throws IOException {
        this.clients=clients;
        this.socket = socket;
        this.serverSocket = serverSocket;
        this.clientNumber = clientNumber;
        clients.add(this);
        this.writeToClient= new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
//        DataOutputStream outputToClient =
//                new DataOutputStream(socket.getOutputStream());
    }//end ctor
    
    
    //run() method is required by all
    //Runnable implementers
    @Override
    public void run() {
        //run the thread in here
        try {
            DataInputStream inputFromClient =
                    new DataInputStream(socket.getInputStream());
            
            DataOutputStream outputToClient = 
                    new DataOutputStream(socket.getOutputStream());
            File myfile = new File("input"); //open file
            Boolean login = false;
            String name=null;

            //server loop listening for the client
            //and responding
            //continuously serve the client
            while(true) {
                String strReceived = inputFromClient.readUTF();
                System.out.println("\n\t[[Command " + strReceived +
                        " received from client " + clientNumber +"]]");

                System.out.println("Command Recieved: "+strReceived);
                String[] command = strReceived.split(" ");
                if (strReceived.toLowerCase().startsWith("login "))  // if the command is login
                {
                    BufferedReader br = new BufferedReader(new FileReader(myfile));
                    Scanner read = new Scanner(myfile);
                    String line;
                    String user = strReceived.substring(6);
                    while ((line = br.readLine()) != null) // search for the username and password in the file
                    {
                        if (line.equals(user)) {
                            System.out.println("Sending Success to client");
                            outputToClient.writeUTF("SUCCESS");
                            name = command[1];
                            login = true;
                            break;
                        }
                    }
                    if (login == false) // if username or password not found
                    {
                        System.out.println("FAILURE: Please provide correct username and password.");
                        outputToClient.writeUTF("FAILURE: Please provide correct username and password.");

                    }

                }
                else if(strReceived.equalsIgnoreCase("logout")) // logout command
                {
                    if(login==true) // check if the user logged in
                    {
                        login=false;
                        name=null;
                        System.out.println("200 Ok");
                        outputToClient.writeUTF("200 Ok");
                    }
                    else //users can not log out if they are not logged in
                    {
                        System.out.println("You are not logged in!!");
                        outputToClient.writeUTF("You are not logged in!!");

                    }
                }
                else if (strReceived.toLowerCase().startsWith("solve ") && command.length > 1 )
                // if the solve command is entered
                {
                    if (login == true) // Must be logged in
                    {
                        FileWriter outputfile = new FileWriter(name+"_solution.txt", true); //create output file
                        if (strReceived.toLowerCase().startsWith("solve -c ") ) // check if it is a circle
                        {
                            if (strReceived.equalsIgnoreCase("solve -c ")) // if users didn't enter the radius
                            {
                                System.out.println("Error, No radius found!!");
                                outputToClient.writeUTF("Error, No radius found!!");
                                outputfile.write("Error, No radius found!!\n");

                            }
                            else  if (Character.isDigit(strReceived.charAt(9)))
                            {
                                int radius = Integer.parseInt(String.valueOf(strReceived.charAt(9)));
                                float cir = radius * 2 * 3.14f;
                                float area = radius * radius * 3.14f;
                                System.out.println("Circle’s circumference is " + cir + " and area is " + area);
                                outputToClient.writeUTF("Circle’s circumference is " + cir + " and area is " + area);
                                outputfile.write("Circle’s circumference is " + cir + " and area is " + area+"\n");
                            }
                            else // invalid command
                            {
                                System.out.println("300 invalid command");
                                outputToClient.writeUTF("300 invalid command");
                                outputfile.write("300 invalid command\n");
                            }

                        }
                        else if (strReceived.toLowerCase().startsWith("solve -r ")) // chcek if it  is a rectangle
                        {
                            if (strReceived.equalsIgnoreCase("solve -r "))
                            {
                                System.out.println("Error, No sides found!!");
                                outputToClient.writeUTF("Error, No sides found!!");
                                outputfile.write("Error, No sides found!!\n");

                            }
                            else if (Character.isDigit(strReceived.charAt(9))) {
                                int side1 = Integer.parseInt(String.valueOf(strReceived.charAt(9)));
                                int side2;
                                if(command.length == 4 && Character.isDigit(strReceived.charAt(11))) //check if it a square or rectangle
                                    side2 = Integer.parseInt(String.valueOf(strReceived.charAt(11)));
                                else
                                    side2 = side1;
                                System.out.println(side1 + " "+ side2);
                                float parameter = (side1 + side2) * 2f;
                                float area = side1 * side2;


                                System.out.println("Rectangle’s Parameter is " + parameter + " and area is " + area);
                                outputToClient.writeUTF("Rectangle’s Parameter is " + parameter + " and area is " + area);
                                outputfile.write("Rectangle’s Parameter is " + parameter + " and area is " + area+"\n");
                            }
                            else
                            {
                                System.out.println("300 invalid command");
                                outputToClient.writeUTF("300 invalid command");
                                outputfile.write("300 invalid command\n");
                            }
                        }
                        else
                        {
                            System.out.println("300 invalid command");
                            outputToClient.writeUTF("300 invalid command");
                            outputfile.write("300 invalid command\n");
                        }
                        outputfile.close();
                    }
                    else // users aren't logged in can't solve
                    {
                        System.out.println("You can't solve before you login");
                        outputToClient.writeUTF("You can't solve before you login");
                    }
                }
                else if(strReceived.equalsIgnoreCase("list")) // list command
                {
                    if(login==true) // Must be logged in
                    {
                        File dispalyfile = new File (name+"_solution.txt");
                        if(dispalyfile.exists()) // check if file already exists
                        {
                            BufferedReader read = new BufferedReader(new FileReader(name+"_solution.txt"));
                            String line;
                            String output= name ;
                            while((line = read.readLine()) != null)
                            {
                                output= output +"    "+ line + "\n";

                            }
                            System.out.println(output);
                            outputToClient.writeUTF(output);

                        }
                        else // if not, then there is no interactions yet
                        {
                            System.out.println("No interactions yet");
                            outputToClient.writeUTF("No interactions yet");
                        }

                    }
                    else
                    {
                        System.out.println("Login first");
                        outputToClient.writeUTF("Login first");
                    }
                }
                else if(strReceived.equalsIgnoreCase("LIST -all")) //list all command
                {
                    if(login==true && name.equals("root")) // must be root user
                    {
                        BufferedReader br = new BufferedReader(new FileReader(myfile)); // loop through the usernames (input.txt)
                        Scanner reader = new Scanner(myfile);
                        String line;
                        String output= "";
                        while ((line = br.readLine()) != null)
                        // loop through the user, and check if there is an _solution.txt file for each of them.
                        {
                            String[] users = line.split(" ");
                            output= output +"\n"+ users[0] ;
                            File dispalyfile = new File (users[0]+"_solution.txt");
                            if(dispalyfile.exists())
                            {
                                BufferedReader read = new BufferedReader(new FileReader(users[0]+"_solution.txt"));
                                String readFile;

                                while((readFile = read.readLine()) != null)
                                {
                                    output= output +"    "+ readFile + "\n"; // copy the file to the string
                                }
                            }
                            else // else if the _solution.txt file not found, then there is no interaction yet
                                output = output +"\n    No interactions yet";
                        }
                        System.out.println(output);
                        outputToClient.writeUTF(output);
                    }
                    else
                    {
                        System.out.println("Error: you are not the root user");
                        outputToClient.writeUTF("Error: you are not the root user");
                    }
                }
                else if (strReceived.toLowerCase().startsWith("message -all")) // Message command for the root user
                {
                    String message= strReceived.substring(13);
                    if(login==true && name.equals("root"))
                    {
                        for(ClientHandler client : clients)
                        {
                            System.out.println("root send the following message: "+message);
                            outputToClient.writeUTF("root send the following message: "+message);
                            client.writeToClient.write("root send the following message: "+message);
                            client.writeToClient.newLine();
                            client.writeToClient.flush();
                        }
                    }
                    else
                    {
                        System.out.println("Error: Only the root user could use this command");
                        outputToClient.writeUTF("Error: Only the root user could use this command");

                    }

                }
                else if (strReceived.toLowerCase().startsWith("message ")) // Message command
                {
                    if(login==true )
                    {
                        String sendto = command[1];
                        String message= strReceived.substring(8);
                        for(ClientHandler client : clients)
                        {
                            System.out.println("You send the following message to " + message);
                            outputToClient.writeUTF("you sent the following message to :"+strReceived);
                            client.writeToClient.write(command[1]);
                            client.writeToClient.newLine();
                            client.writeToClient.flush();

                        }
                    }
                    else
                    {
                        System.out.println("Error: You have to login before you send any message");
                        outputToClient.writeUTF("Error: You have to login before you send any message");

                    }

                }
                else if (strReceived.equalsIgnoreCase("SHUTDOWN")) { //shutdown command
                    System.out.println("200 Ok");
                    outputToClient.writeUTF("200 OK");
                    serverSocket.close();
                    socket.close();
                    break;  //get out of loop
                }
                else // invalid command
                {
                    System.out.println("“300 invalid command: "
                            + strReceived);
                    outputToClient.writeUTF("“300 invalid command.  "
                            + "Please try again.");

                }
            }//end while
        }
        catch(IOException ex) {
            ex.printStackTrace();
        }//end try-catch
        
    }//end run
    
}//end ClientHandler
