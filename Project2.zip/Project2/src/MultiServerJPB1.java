
import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


public class MultiServerJPB1 {
    
    private static final int SERVER_PORT = 8765;
    private static ArrayList<ClientHandler> clients = new ArrayList<>();
    
    public static void main(String[] args) {
        //createCommunicationLoop();
        createMultithreadCommunicationLoop();
    }//end main

    public static void createMultithreadCommunicationLoop() {
        int clientNumber = 0;
        
        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            System.out.println("Server started on " + new Date() + ".");
            //listen for new connection request
            while(true) {
                Socket socket = serverSocket.accept();
                clientNumber++;  //increment client num
            
                //Find client's host name 
                //and IP address
                InetAddress inetAddress = socket.getInetAddress();
                System.out.println("Connection from client " + 
                        clientNumber);
                System.out.println("\tHost name: " + 
                        inetAddress.getHostName());
                System.out.println("\tHost IP address: "+
                        inetAddress.getHostAddress());
                
                //create and start new thread for the connection
                Thread clientThread = new Thread(
                        new ClientHandler(clientNumber, socket, serverSocket, clients));
                ClientHandler clientHandler = new ClientHandler(clientNumber, socket, serverSocket, clients);
                clients.add(clientHandler);
                clientThread.start();

            }//end while           
        }
        catch(IOException ex) {
            ex.printStackTrace();
        }
        
    }//end createMultithreadCommunicationLoop
    
    public static void createCommunicationLoop() {
        try {
            //create server socket
            ServerSocket serverSocket = 
                    new ServerSocket(SERVER_PORT);
            
            System.out.println("Server started at " +
                    new Date() + "\n");
            //listen for a connection
            //using a regular *client* socket
            Socket socket = serverSocket.accept();
            
            //now, prepare to send and receive data
            //on output streams
            DataInputStream inputFromClient = 
                    new DataInputStream(socket.getInputStream());
            
            DataOutputStream outputToClient =
                    new DataOutputStream(socket.getOutputStream());
            
            //server loop listening for the client 
            //and responding
            File myfile = new File("input"); //open file
            Boolean login = false;
            String name=null;
            //server loop listening for the client
            //and responding
            while(true) {
                String strReceived = inputFromClient.readUTF();
                
//                if(strReceived.equalsIgnoreCase("hello")) {
//                    System.out.println("Sending hello to client");
//                    outputToClient.writeUTF("hello client!");
//                }
//                else if(strReceived.equalsIgnoreCase("quit")) {
//                    System.out.println("Shutting down server...");
//                    outputToClient.writeUTF("Shutting down server...");
//                    serverSocket.close();
//                    socket.close();
//                    break;  //get out of loop
//                }
//                else {
//                    System.out.println("Unknown command received: "
//                        + strReceived);
//                    outputToClient.writeUTF("Unknown command.  "
//                            + "Please try again.");
//
//                }
                System.out.println("Command Recieved: "+strReceived);
                String[] command = strReceived.split(" ");
                if (strReceived.toLowerCase().startsWith("login "))  // if the command is login
                {
                    BufferedReader br = new BufferedReader(new FileReader(myfile));
                    Scanner read = new Scanner(myfile);
                    String line;
                    String user = strReceived.substring(6);
                    while ((line = br.readLine()) != null) // search for the username and password in the file
                    {
                        if (line.equals(user)) {
                            System.out.println("Sending Success to client");
                            outputToClient.writeUTF("SUCCESS");
                            name = command[1];
                            login = true;
                            break;
                        }
                    }
                    if (login == false) // if username or password not found
                    {
                        System.out.println("FAILURE: Please provide correct username and password.");
                        outputToClient.writeUTF("FAILURE: Please provide correct username and password.");

                    }

                }
                else if(strReceived.equalsIgnoreCase("logout")) // logout command
                {
                    if(login==true) // check if the user logged in
                    {
                        login=false;
                        name=null;
                        System.out.println("200 Ok");
                        outputToClient.writeUTF("200 Ok");
                    }
                    else //users can not log out if they are not logged in
                    {
                        System.out.println("You are not logged in!!");
                        outputToClient.writeUTF("You are not logged in!!");

                    }
                }
                else if (strReceived.toLowerCase().startsWith("solve ") && command.length > 1 )
                // if the solve command is entered
                {
                    if (login == true) // Must be logged in
                    {
                        FileWriter outputfile = new FileWriter(name+"_solution.txt", true); //create output file
                        if (strReceived.toLowerCase().startsWith("solve -c ") ) // check if it is a circle
                        {
                            if (strReceived.equalsIgnoreCase("solve -c ")) // if users didn't enter the radius
                            {
                                System.out.println("Error, No radius found!!");
                                outputToClient.writeUTF("Error, No radius found!!");
                                outputfile.write("Error, No radius found!!\n");

                            }
                            else  if (Character.isDigit(strReceived.charAt(9)))
                            {
                                int radius = Integer.parseInt(String.valueOf(strReceived.charAt(9)));
                                float cir = radius * 2 * 3.14f;
                                float area = radius * radius * 3.14f;
                                System.out.println("Circle’s circumference is " + cir + " and area is " + area);
                                outputToClient.writeUTF("Circle’s circumference is " + cir + " and area is " + area);
                                outputfile.write("Circle’s circumference is " + cir + " and area is " + area+"\n");
                            }
                            else // invalid command
                            {
                                System.out.println("300 invalid command");
                                outputToClient.writeUTF("300 invalid command");
                                outputfile.write("300 invalid command\n");
                            }

                        }
                        else if (strReceived.toLowerCase().startsWith("solve -r ")) // chcek if it  is a rectangle
                        {
                            if (strReceived.equalsIgnoreCase("solve -r "))
                            {
                                System.out.println("Error, No sides found!!");
                                outputToClient.writeUTF("Error, No sides found!!");
                                outputfile.write("Error, No sides found!!\n");

                            }
                            else if (Character.isDigit(strReceived.charAt(9))) {
                                int side1 = Integer.parseInt(String.valueOf(strReceived.charAt(9)));
                                int side2;
                                if(command.length == 4 && Character.isDigit(strReceived.charAt(11))) //check if it a square or rectangle
                                    side2 = Integer.parseInt(String.valueOf(strReceived.charAt(11)));
                                else
                                    side2 = side1;
                                System.out.println(side1 + " "+ side2);
                                float parameter = (side1 + side2) * 2f;
                                float area = side1 * side2;


                                System.out.println("Rectangle’s Parameter is " + parameter + " and area is " + area);
                                outputToClient.writeUTF("Rectangle’s Parameter is " + parameter + " and area is " + area);
                                outputfile.write("Rectangle’s Parameter is " + parameter + " and area is " + area+"\n");
                            }
                            else
                            {
                                System.out.println("300 invalid command");
                                outputToClient.writeUTF("300 invalid command");
                                outputfile.write("300 invalid command\n");
                            }
                        }
                        else
                        {
                            System.out.println("300 invalid command");
                            outputToClient.writeUTF("300 invalid command");
                            outputfile.write("300 invalid command\n");
                        }
                        outputfile.close();
                    }
                    else // users aren't logged in can't solve
                    {
                        System.out.println("You can't solve before you login");
                        outputToClient.writeUTF("You can't solve before you login");
                    }
                }
                else if(strReceived.equalsIgnoreCase("list")) // list command
                {
                    if(login==true) // Must be logged in
                    {
                        File dispalyfile = new File (name+"_solution.txt");
                        if(dispalyfile.exists()) // check if file already exists
                        {
                            BufferedReader read = new BufferedReader(new FileReader(name+"_solution.txt"));
                            String line;
                            String output= name ;
                            while((line = read.readLine()) != null)
                            {
                                output= output +"    "+ line + "\n";

                            }
                            System.out.println(output);
                            outputToClient.writeUTF(output);

                        }
                        else // if not, then there is no interactions yet
                        {
                            System.out.println("No interactions yet");
                            outputToClient.writeUTF("No interactions yet");
                        }

                    }
                    else
                    {
                        System.out.println("Login first");
                        outputToClient.writeUTF("Login first");
                    }
                }
                else if(strReceived.equalsIgnoreCase("LIST -all")) //list all command
                {
                    if(login==true && name.equals("root")) // must be root user
                    {
                        BufferedReader br = new BufferedReader(new FileReader(myfile)); // loop through the usernames (input.txt)
                        Scanner reader = new Scanner(myfile);
                        String line;
                        String output= "";
                        while ((line = br.readLine()) != null)
                        // loop through the user, and check if there is an _solution.txt file for each of them.
                        {
                            String[] users = line.split(" ");
                            output= output +"\n"+ users[0] ;
                            File dispalyfile = new File (users[0]+"_solution.txt");
                            if(dispalyfile.exists())
                            {
                                BufferedReader read = new BufferedReader(new FileReader(users[0]+"_solution.txt"));
                                String readFile;

                                while((readFile = read.readLine()) != null)
                                {
                                    output= output +"    "+ readFile + "\n"; // copy the file to the string
                                }
                            }
                            else // else if the _solution.txt file not found, then there is no interaction yet
                                output = output +"\n    No interactions yet";
                        }
                        System.out.println(output);
                        outputToClient.writeUTF(output);
                    }
                    else
                    {
                        System.out.println("Error: you are not the root user");
                        outputToClient.writeUTF("Error: you are not the root user");
                    }
                }
                else if (strReceived.equalsIgnoreCase("SHUTDOWN")) { //shutdown command
                    System.out.println("200 Ok");
                    outputToClient.writeUTF("200 OK");
                    serverSocket.close();
                    socket.close();
                    break;  //get out of loop
                }
                else // invalid command
                {
                    System.out.println("“300 invalid command: "
                            + strReceived);
                    outputToClient.writeUTF("“300 invalid command.  "
                            + "Please try again.");

                }
            }//end server loop
        }
        catch(IOException ex) {
            ex.printStackTrace();
        }//end try-catch
    }//end createCommunicationLoop
}
